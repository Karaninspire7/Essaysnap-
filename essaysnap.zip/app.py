from flask import Flask, request, jsonify
import openai
import os

app = Flask(__name__)

openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/")
def home():
    return "EssaySnap AI is Live!"

@app.route("/generate-essay", methods=["POST"])
def generate_essay():
    data = request.json
    topic = data.get("topic", "Default Essay Topic")
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert essay writer."},
                {"role": "user", "content": f"Write an essay on: {topic}"}
            ],
            max_tokens=500
        )
        content = response.choices[0].message.content.strip()
        return jsonify({"essay": content})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
