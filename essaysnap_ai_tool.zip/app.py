from flask import Flask, request, jsonify
import openai
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Replace with your own OpenAI API key securely
openai.api_key = "sk-proj-XXX-YOURKEY-HERE"

@app.route("/api/generate", methods=["POST"])
def generate_essay():
    data = request.get_json()
    prompt = data.get("prompt", "")
    if not prompt:
        return jsonify({"error": "Prompt is missing"}), 400

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": f"Write an essay on: {prompt}"}],
            max_tokens=500,
            temperature=0.7,
        )
        essay = response.choices[0].message["content"]
        return jsonify({"essay": essay})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
